# Netflix Actor–Director Collaboration Network Analysis

## 1. Introduction
This project explores professional relationships between cast members and directors in the Netflix Movies and TV Shows catalogue. The network is undirected: nodes represent actors or directors and an edge links two people who worked on the same title. The analysis explores repeated partnerships, frequently appearing people, and how the network varies by release decade.

## 2. Data and preparation
The original Netflix catalogue contained 8,807 rows and 11 columns. Records missing either cast or director information were excluded. The first four cast names per title and all listed directors were retained. The resulting working dataset contained **5,700 titles**.

## 3. Network construction
The network was constructed with NetworkX. Actor and director node labels were role-prefixed (`Actor:` and `Director:`). Each title creates links between every pair of included people, so actor–actor, actor–director, and director–director relationships are included. Edge weights count the number of titles shared by each pair.

| Metric | Result |
|---|---:|
| Actor nodes | 12,523 |
| Director nodes | 4,529 |
| Total nodes | 17,052 |
| Unique edges | 50,823 |

## 4. Actor–director partnerships
There were **21,523 unique actor–director partnerships** in the pair-count analysis. Strongest partnerships included:

| Actor | Director | Shared titles |
|---|---|---:|
| Rupa Bhimani | Rajiv Chilaka | 18 |
| Julie Tejwani | Rajiv Chilaka | 17 |
| Jigna Bhardwaj | Rajiv Chilaka | 17 |
| Vatsal Dubey | Rajiv Chilaka | 16 |
| Saurav Chakraborty | Suhas Kadav | 8 |
| Rana Daggubati | S.S. Rajamouli | 7 |
| Kappei Yamaguchi | Toshiya Shinohara | 7 |
| Satsuki Yukino | Toshiya Shinohara | 7 |
| Koji Tsujitani | Toshiya Shinohara | 7 |
| Prabhas | S.S. Rajamouli | 7 |
| Tamannaah Bhatia | S.S. Rajamouli | 7 |
| Anushka Shetty | S.S. Rajamouli | 7 |

The small network visualization of the strongest relationships highlights repeated connections, including multiple partnerships involving Rajiv Chilaka.

## 5. Actor–actor collaborations
The analysis identified **28,185 unique actor pairs**. The strongest partnership was Julie Tejwani and Rupa Bhimani, with 26 shared titles. Other notable pairs included Julie Tejwani and Vatsal Dubey, Jigna Bhardwaj and Julie Tejwani, and John Paul Tremblay and Robb Wells.

![Top actor partnerships](visualizations/top_actor_pairs.png)

## 6. Frequently appearing actors
The highest actor counts in the prepared dataset were:

| Actor | Titles |
|---|---:|
| Shah Rukh Khan | 35 |
| Akshay Kumar | 28 |
| Rupa Bhimani | 27 |
| Julie Tejwani | 26 |
| Amitabh Bachchan | 25 |
| Anupam Kher | 22 |
| Kareena Kapoor | 22 |
| Naseeruddin Shah | 21 |
| Adam Sandler | 20 |
| Ajay Devgn | 20 |
| Samuel L. Jackson | 18 |
| Jigna Bhardwaj | 18 |
| Kay Kay Menon | 18 |
| Nawazuddin Siddiqui | 18 |
| Om Puri | 18 |

## 7. Frequently appearing directors
The most frequently appearing directors were:

| Director | Titles |
|---|---:|
| Jan Suter | 21 |
| Rajiv Chilaka | 19 |
| Raúl Campos | 19 |
| Marcus Raboy | 16 |
| Jay Karas | 15 |
| Suhas Kadav | 13 |
| Cathy Garcia-Molina | 13 |
| Youssef Chahine | 12 |
| Martin Scorsese | 12 |
| Jay Chapman | 12 |
| Steven Spielberg | 11 |
| Don Michael Paul | 10 |
| David Dhawan | 9 |
| Yılmaz Erdoğan | 9 |
| Anurag Kashyap | 9 |

These counts indicate frequency within this filtered dataset, not audience popularity or commercial success.

## 8. Collaboration networks by decade
Titles were grouped by release decade and a separate graph was constructed for each group.

| Decade | Titles | People (nodes) | Unique edges |
|---|---:|---:|---:|
| 1940s | 5 | 16 | 31 |
| 1950s | 11 | 48 | 108 |
| 1960s | 23 | 107 | 233 |
| 1970s | 63 | 273 | 609 |
| 1980s | 121 | 488 | 1,119 |
| 1990s | 237 | 916 | 2,227 |
| 2000s | 673 | 2,317 | 6,551 |
| 2010s | 3,812 | 12,439 | 33,723 |
| 2020s | 755 | 3,217 | 6,926 |

![Titles by decade](visualizations/titles_by_decade.png)

The 2010s had the most titles, nodes, and unique edges in this dataset. Dataset size is a major factor in these totals.

## 9. Weighted collaboration occurrences
Edge weights were summed within each decade. This counts collaboration occurrences (pairs of people appearing together on a title), rather than only unique edges.

| Decade | Titles | Occurrences | Occurrences per title |
|---|---:|---:|---:|
| 1940s | 5 | 31 | 6.20 |
| 1950s | 11 | 115 | 10.45 |
| 1960s | 23 | 235 | 10.22 |
| 1970s | 63 | 633 | 10.05 |
| 1980s | 121 | 1,210 | 10.00 |
| 1990s | 237 | 2,302 | 9.71 |
| 2000s | 673 | 6,893 | 10.24 |
| 2010s | 3,812 | 35,244 | 9.25 |
| 2020s | 755 | 7,149 | 9.47 |

![Weighted collaborations by decade](visualizations/collaborations_by_decade.png)

The 2010s contributed the greatest number of collaboration occurrences. The 1950s had the highest occurrences-per-title ratio (10.45), but this is based on only 11 titles and should be interpreted cautiously. The ratio remained broadly near ten across many decades.

## 10. Conclusions
The analysis shows that Netflix catalogue data can be used to uncover repeated professional relationships. Julie Tejwani and Rupa Bhimani were the strongest actor pair in the results, while Rupa Bhimani and Rajiv Chilaka had the strongest actor–director partnership. Shah Rukh Khan and Jan Suter led the actor and director title-count rankings, respectively. The 2010s were the largest decade group by titles and network size.

## 11. Limitations
- Only the first four cast members listed per title were included.
- Titles without cast or director data were removed, leaving 5,700 records.
- Netflix catalogue availability is not a complete representation of the entertainment industry.
- Counts reflect appearances and collaborations, not popularity, quality, or commercial performance.
- Actor and director roles are role-prefixed; a person appearing in both roles is represented as separate nodes.
- Decade totals are affected by the number of titles available in the dataset. The 2020s are incomplete.
- Connections per title and weighted collaboration occurrences are descriptive measures, not formal network-density metrics.

## 12. Tools
Python, Pandas, NumPy, NetworkX, Matplotlib, itertools, and collections.
