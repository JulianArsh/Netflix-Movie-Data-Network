# Netflix Actor–Director Collaboration Network

Portfolio assets generated from the completed notebook analysis.

## Contents
- `report.md` — full portfolio report
- `actor_director_network.png` — top actor–director partnership network
- `actor_actor_collaborations.png` — strongest actor–actor pairs
- `top_actors.png` — frequent actors
- `top_directors.png` — frequent directors
- `titles_by_decade.png` — titles by release decade
- `collaboration_per_title.png` — collaboration occurrences per title

Place these files beside your notebook (or in a `reports/` folder). The figures are generated from the values reported during the notebook analysis.
